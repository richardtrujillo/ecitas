






package org.ModulePresentacion;

import org.junit.Test;

import junit.framework.TestCase;


public class TestPresentacion extends TestCase {
	
	
	@Test
	public void testPresentacion1() {
		Especialista e= new Especialista();
		e.frmEspecialista.setVisible(true);
		assertNotNull(e);	
	}
	
	
//	@Test
//	public void testPresentacion2() {
//		VentanaPrincipal v = new VentanaPrincipal();
//		v.frmeCitas.setVisible(true);
//		assertNotNull(v);	
//	}
//	

}
