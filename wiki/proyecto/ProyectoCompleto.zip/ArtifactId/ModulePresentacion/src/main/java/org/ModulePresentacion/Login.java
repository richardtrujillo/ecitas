package org.ModulePresentacion;

import java.awt.EventQueue;


import javax.swing.JFrame;
import javax.swing.JPanel;


import javax.swing.JLabel;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;

import java.util.Arrays;

import javax.swing.border.Border;
import javax.swing.BorderFactory;


public class Login {

	private JFrame frmAutenticar;
	private JPanel panel;
	private JLabel lblLogo;
	private JLabel lblLogin;
	private JLabel lblContrasea;
	private JTextField txtLogin;
	private JLabel lblAviso;
	private JPasswordField pswfContraseña;
	private JButton btnEntrar;
	private final static char[] password={'i','p','o','1'};
	private Border bordeRojo = BorderFactory.createLineBorder(Color.RED);
	private Border bordeVerde = BorderFactory.createLineBorder(Color.GREEN);
	private JLabel lblLogin2;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login window = new Login();
					window.frmAutenticar.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Login() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAutenticar = new JFrame();
		frmAutenticar.setBounds(100, 100, 406, 206);
		frmAutenticar.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAutenticar.getContentPane().setLayout(null);
		{
			panel = new JPanel();
			//Se puede quitar
			//panel.addMouseListener(new PanelMouseListener());
			panel.setBounds(0, 0, 388, 167);
			frmAutenticar.getContentPane().add(panel);
			panel.setLayout(null);
			{
				lblLogo = new JLabel("");
				lblLogo.setIcon(new ImageIcon(Login.class.getResource("/org/ModulePresentacion/NUEVO_LOGO_75.png")));
				//Se puede quitar
//				lblLogo.addMouseListener(new LblLogoMouseListener());
				lblLogo.setBounds(26, 11, 128, 121);
				panel.add(lblLogo);
			}
			{
				lblLogin = new JLabel("         Login:");
				lblLogin.setBounds(164, 30, 93, 14);
				panel.add(lblLogin);
			}
			{
				lblContrasea = new JLabel("Contraseña:");
				lblContrasea.setEnabled(false);
				lblContrasea.setBounds(187, 70, 86, 14);
				panel.add(lblContrasea);
			}
			{
				txtLogin = new JTextField();
				txtLogin.addKeyListener(new TxtLoginKeyListener());
				txtLogin.addFocusListener(new MiFocusListener());
				txtLogin.addActionListener(new TxtfUsuarioActionListener());
				txtLogin.setBounds(273, 27, 86, 20);
				panel.add(txtLogin);
				txtLogin.setColumns(10);
			}
			{
				lblAviso = new JLabel("");
				lblAviso.setBounds(20, 128, 253, 28);
				panel.add(lblAviso);
			}
			{
				pswfContraseña = new JPasswordField();
				pswfContraseña.addFocusListener(new MiFocusListener());
				pswfContraseña.addActionListener(new PswfPasswordActionListener());
				pswfContraseña.setEnabled(false);
				pswfContraseña.setBounds(273, 67, 86, 20);
				panel.add(pswfContraseña);
			}
			{
				btnEntrar = new JButton("Entrar");
				btnEntrar.addKeyListener(new BtnEntrarKeyListener());
				btnEntrar.addActionListener(new BtnEntrarActionListener());
				btnEntrar.setEnabled(false);
				btnEntrar.setBounds(270, 120, 89, 23);
				panel.add(btnEntrar);
			}
			{
				lblLogin2 = new JLabel("");
				lblLogin2.setBounds(359, 30, 29, 14);
				panel.add(lblLogin2);
			}
		}
	}
	
	//Se puede quitar PONERLO AHORA DESPUES
	
//	private class LblLogoMouseListener extends MouseAdapter { 
//		ImageIcon fotoOriginal=new ImageIcon(Login.class.getResource("/presentacion/039.png"));
//		ImageIcon fotoCambio=new ImageIcon(Login.class.getResource("/presentacion/NUEVO_LOGO.png")); 
//		@Override 
//		public void mouseEntered(MouseEvent e) {
//			//Al entrar el ratón en la etiqueta, cambia la imagen 
//			//lblEstado.setText("Evento de Ratón: MouseEntered "+e.getSource()); 
//			lblLogo.setIcon(fotoCambio);
//		} 
//		@Override 
//		public void mouseExited(MouseEvent e) { 
//			//Al salir el ratón de la etiqueta, recupera la imagen original 
//			//lblEstado.setText("Evento de Ratón: MouseExited "+e.getSource()); 
//			lblLogo.setIcon(fotoOriginal); 
//		} 
//	}
	
	private class TxtfUsuarioActionListener implements ActionListener { 
		public void actionPerformed(ActionEvent arg0) { 
			//lblEstado.setText("Evento de acción: ActionPerformed "+arg0.getActionCommand() ); 
			//Desactivamos los campos de los datos del usuario 
			if (String.valueOf(txtLogin.getText()).equals("Exp345")){
				lblLogin.setEnabled(false); 
				txtLogin.setEnabled(false);
				lblContrasea.setEnabled(true); 
				pswfContraseña.setEnabled(true); //Solicitamos el foco en el campo de la contraseña (el cursor se activa ahí) 
				pswfContraseña.requestFocus(); 
			}else{
				lblLogin.setEnabled(true); 
				txtLogin.setEnabled(true); 
			} 
		}
	}
	
	private class PswfPasswordActionListener implements ActionListener { 
		public void actionPerformed(ActionEvent e) { 
			//lblEstado.setText("Evento de Acción: ActionPerformed "+e.getActionCommand()); 
			//obtenemos la contraseña introducida 
			char[] passwordIntro=pswfContraseña.getPassword(); 
			if (esPasswordCorrecta(passwordIntro)) 
				activarEntrar(); 
			else activarCorregir(); 
		}
	}

	
	private static boolean esPasswordCorrecta(char[] input) {
		boolean esCorrecta = true;
		if (input.length != password.length) {
			esCorrecta = false;
		} else {
			esCorrecta = Arrays.equals (input, password);
		}
		return esCorrecta;
	}

	private void activarEntrar(){
		lblAviso.setBackground(Color.green);
		lblAviso.setText("Contraseña correcta. Puede entrar");
		lblAviso.setVisible(true);
		btnEntrar.setEnabled(true);
		lblContrasea.setEnabled(false);
		pswfContraseña.setEnabled(false);
		//chckbxVerLogo.setEnabled(false);
	}
	
	private void activarCorregir(){
		lblAviso.setBackground(Color.red);
		lblAviso.setText("Contraseña incorrecta. Vuelva a intentarlo");
		lblAviso.setVisible(true);
		btnEntrar.setEnabled(false);
	}
	//Para el logo si se quiere
//	private class ChckbxVerLogoItemListener implements ItemListener { 
//		public void itemStateChanged(ItemEvent e) { 
//			if (chckbxVerLogo.isSelected()){ //si está seleccionado, mostramos la etiqueta 
//				//eliminar estra
//				lblAviso.setText("Evento de Item: ItemStateChanged.Checkbox "+e.getStateChange()); 
//				lblLogo.setVisible(true);
//			} else {//si no, no mostramos la etiqueta 
//				//eliminar esta
//				lblAviso.setText("Evento de Item: ItemStateChanged Checkbox "+e.getStateChange()); 
//				lblLogo.setVisible(false); 
//			}
//		}
//	}
	
	private class TxtLoginKeyListener extends KeyAdapter {
		@Override
		public void keyReleased(KeyEvent arg0) {
			if (String.valueOf(txtLogin.getText()).equals("Exp345")){
				txtLogin.setBorder(bordeVerde);
				lblLogin2.setIcon(new ImageIcon(Login.class.getResource("/org/ModulePresentacion/tick.PNG")));
			} else{
				txtLogin.setBorder(bordeRojo);
				lblLogin2.setIcon(new ImageIcon(Login.class.getResource("/org/ModulePresentacion/cross.PNG")));
			}
		}
	}
	
	private class MiFocusListener extends FocusAdapter {
		@Override
		public void focusGained(FocusEvent e) {
			e.getComponent().setBackground(new Color(250, 250, 210));
		}

		@Override
		public void focusLost(FocusEvent e) {
			e.getComponent().setBackground(new Color(250, 250, 250));
		}
	}
	
	private class BtnEntrarActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			VentanaPrincipal window = new VentanaPrincipal();
			window.frmeCitas.setVisible(true);
			
		}
	}
	private class BtnEntrarKeyListener extends KeyAdapter {
		@Override
		public void keyPressed(KeyEvent e) {
			VentanaPrincipal window= new VentanaPrincipal();
			window.frmeCitas.setVisible(true);
		}
	}

}

