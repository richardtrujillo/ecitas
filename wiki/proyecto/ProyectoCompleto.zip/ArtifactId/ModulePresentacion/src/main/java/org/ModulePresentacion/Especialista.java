package org.ModulePresentacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;

import javax.swing.JLabel;

import java.awt.GridBagConstraints;
import java.awt.Insets;

import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JScrollPane;
import javax.swing.JFormattedTextField;
import javax.swing.JRadioButton;
import javax.swing.JComboBox;
import javax.swing.JButton;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.ArrayList;

import javax.swing.DefaultComboBoxModel;

//import persistencia.Especialista_BD;
import org.ModuleEspecialista.*;

public class Especialista{

	JFrame frmEspecialista;
	private JPanel panel;
	private JLabel lblNombre;
	private JTextField tbNombre;
	private JLabel lblApellidos;
	private JTextField tbApellidos;
	private JLabel lblEspecialidad;
	private JLabel label_3;
	private JFormattedTextField tbDNI;
	private JButton btLimpiar;
	private JButton btGuardar;
	private JComboBox cbEspecialidad;
	private JLabel lblNcolegiado;
	private JLabel lblNconsulta;
	private JTextField tbNColegiado;
	private JTextField tbNumConsulta;
	private JLabel lblEmail;
	private JTextField tbEmail;
	
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Especialista window = new Especialista();
					window.frmEspecialista.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Especialista() {
		initialize();
	}
	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmEspecialista = new JFrame();
		frmEspecialista.setTitle("Especialista");
		frmEspecialista.setBounds(100, 100, 512, 235);
		frmEspecialista.getContentPane().setLayout(new GridLayout(0, 1, 0, 0));
		{
			panel = new JPanel();
			frmEspecialista.getContentPane().add(panel);
			panel.setLayout(null);
			{
				lblNombre = new JLabel(" Nombre:");
				lblNombre.setBounds(32, 33, 60, 14);
				panel.add(lblNombre);
			}
			{
				tbNombre = new JTextField();
				tbNombre.setBounds(91, 30, 303, 20);
				tbNombre.setColumns(10);
				panel.add(tbNombre);
			}
			{
				lblApellidos = new JLabel("Apellidos:");
				lblApellidos.setBounds(31, 59, 61, 14);
				panel.add(lblApellidos);
			}
			{
				tbApellidos = new JTextField();
				tbApellidos.setBounds(91, 56, 303, 20);
				tbApellidos.setColumns(10);
				panel.add(tbApellidos);
			}
			{
				btLimpiar = new JButton(" Limpiar ");
				btLimpiar.addActionListener(new BtLimpiarActionListener());
				btLimpiar.setBounds(401, 55, 85, 23);
				panel.add(btLimpiar);
			}
			{
				lblEspecialidad = new JLabel("Especialidad:");
				lblEspecialidad.setBounds(11, 86, 81, 14);
				panel.add(lblEspecialidad);
			}
			{
				cbEspecialidad = new JComboBox();
				cbEspecialidad.setModel(new DefaultComboBoxModel(new String[] {"Oftalmolog\u00EDa", "Dermatolog\u00EDa", "Med. Interna", "Digestivo", "Fisioterapia"}));
				cbEspecialidad.setBounds(91, 83, 102, 20);
				panel.add(cbEspecialidad);
			}
			{
				label_3 = new JLabel("DNI:");
				label_3.setBounds(260, 87, 22, 14);
				panel.add(label_3);
			}
			{
				tbDNI = new JFormattedTextField();
				tbDNI.setBounds(294, 83, 100, 20);
				panel.add(tbDNI);
			}
			{
				lblNcolegiado = new JLabel("N.Colegiado:");
				lblNcolegiado.setBounds(11, 112, 81, 14);
				panel.add(lblNcolegiado);
			}
			{
				tbNColegiado = new JTextField();
				tbNColegiado.setBounds(91, 109, 102, 20);
				panel.add(tbNColegiado);
				tbNColegiado.setColumns(10);
			}
			{
				lblNconsulta = new JLabel("N.Consulta:");
				lblNconsulta.setBounds(219, 112, 75, 14);
				panel.add(lblNconsulta);
			}
			{
				tbNumConsulta = new JTextField();
				tbNumConsulta.setBounds(294, 114, 100, 20);
				panel.add(tbNumConsulta);
				tbNumConsulta.setColumns(10);
			}
			{
				btGuardar = new JButton("Guardar");
				btGuardar.addActionListener(new BtGuardarActionListener());
				frmEspecialista.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
				btGuardar.setBounds(401, 108, 85, 23);
				panel.add(btGuardar);
			}
			{
				lblEmail = new JLabel("e-mail:");
				lblEmail.setBounds(41, 139, 51, 14);
				panel.add(lblEmail);
			}
			{
				tbEmail = new JTextField();
				tbEmail.setBounds(91, 136, 303, 20);
				panel.add(tbEmail);
				tbEmail.setColumns(10);
			}
		}
	}
	private class BtLimpiarActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			tbNColegiado.setText("");
			tbNombre.setText("");
			tbApellidos.setText("");
			tbDNI.setText("");
			tbEmail.setText("");
			tbNumConsulta.setText("");
		}
	}
	private class BtGuardarActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			boolean faltaDato = false;
			int numeroColegiado = 0;
			String apellidos ="";
			String dni ="";
			String email = "";
			String nombre ="";
			int numeroConsulta = 0;
			String especialidad = cbEspecialidad.getSelectedItem().toString();
			
			if(tbNColegiado.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "El campo Nº de Colegiado esta vacío", "Error", JOptionPane.ERROR_MESSAGE);
				faltaDato = true;
			}else{
				numeroColegiado = Integer.parseInt(tbNColegiado.getText());
			}
			
			if(tbApellidos.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "El campo Apellidos esta vacío", "Error", JOptionPane.ERROR_MESSAGE);
				faltaDato = true;
			}else{
				apellidos = tbApellidos.getText();
			}
			
			if(tbDNI.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "El campo DNI esta vacío", "Error", JOptionPane.ERROR_MESSAGE);
				faltaDato = true;
			}else{
				dni = tbDNI.getText();
			}
			
			if(tbEmail.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "El campo E-mail esta vacío", "Error", JOptionPane.ERROR_MESSAGE);
				faltaDato = true;
			}else{
				email = tbEmail.getText();
			}
			
			if(tbNombre.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "El campo Nombre esta vacío", "Error", JOptionPane.ERROR_MESSAGE);
				faltaDato = true;
			}else{
				nombre = tbNombre.getText();
			}
			
			if(tbNumConsulta.getText().isEmpty()){
				JOptionPane.showMessageDialog(null, "El campo Nº de Consulta esta vacío", "Error", JOptionPane.ERROR_MESSAGE);
				faltaDato = true;
			}else{
				numeroConsulta = Integer.parseInt(tbNumConsulta.getText());
			}
			
			if(!faltaDato){
				//dominio.Especialista espe = new dominio.Especialista(numeroColegiado, dni, nombre, apellidos, especialidad, email, numeroConsulta );
				int x= Integer.parseInt(tbNColegiado.getText());
				int y= Integer.parseInt(tbNumConsulta.getText());
				//dominio.Especialista espe = new dominio.Especialista(x , tbDNI.getText(), tbNombre.getText(), tbApellidos.getText(), (String)cbEspecialidad.getSelectedItem(), tbEmail.getText(), y);
				org.ModuleEspecialista.Especialista espe = new org.ModuleEspecialista.Especialista(x , tbDNI.getText(), tbNombre.getText(), tbApellidos.getText(), (String)cbEspecialidad.getSelectedItem(), tbEmail.getText(), y);
				//Especialista_BD especialistaBD = new Especialista_BD();
				org.ModuleEspecialista.Especialista_BD especialistaBD = new org.ModuleEspecialista.Especialista_BD();
				try {
					especialistaBD.Agregar(espe);
					VentanaPrincipal.cargarListas();
					VentanaPrincipal.añadirDatosListaEspecialistas();
					frmEspecialista.dispose();
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}			
			}
		}
	}
}
