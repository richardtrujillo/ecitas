package org.ModulePresentacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.GridBagLayout;

import javax.swing.JComboBox;

import java.awt.GridBagConstraints;
import java.awt.Insets;

import javax.swing.JLabel;
import javax.swing.DefaultComboBoxModel;

import java.awt.Color;
import java.awt.Font;

import javax.swing.ImageIcon;

import java.awt.SystemColor;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import org.ModuleCitas.*;

public class CrerCita {

	JFrame frmCrearCita;
	private JPanel panel;
	private JComboBox cbEspecialista;
	private JComboBox cbdia;
	private JComboBox cbHora;
	private JLabel lblEspecialista;
	private JLabel lblFechas;
	private JLabel lblHora;
	private JLabel lblPaciente;
	private JComboBox cbPaciente;
	private JComboBox cbMes;
	private JComboBox cbAño;
	private JComboBox cbMinutos;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					CrerCita window = new CrerCita();
					window.frmCrearCita.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public CrerCita() {
		initialize();
		cargarDatos();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCrearCita = new JFrame();
		frmCrearCita.setResizable(false);
		frmCrearCita.setTitle("Crear cita");
		frmCrearCita.setBounds(100, 100, 420, 232);
//		frmCrearCita.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		{
			panel = new JPanel();
			panel.setBackground(SystemColor.activeCaption);
			frmCrearCita.getContentPane().add(panel, BorderLayout.CENTER);
			panel.setLayout(null);
			{
				lblEspecialista = new JLabel("Especialista:");
				lblEspecialista.setBounds(20, 72, 71, 14);
				panel.add(lblEspecialista);
			}
			{
				cbEspecialista = new JComboBox();
				cbEspecialista.setBounds(113, 66, 222, 20);
				cbEspecialista.setModel(new DefaultComboBoxModel(new String[] {""}));
				panel.add(cbEspecialista);
			}
			{
				lblPaciente = new JLabel("Paciente:");
				lblPaciente.setBounds(20, 102, 71, 14);
				panel.add(lblPaciente);
			}
			{
				cbPaciente = new JComboBox();
				cbPaciente.setBounds(113, 96, 222, 20);
				panel.add(cbPaciente);
			}
			{
				lblFechas = new JLabel("Fecha:");
				lblFechas.setBounds(20, 130, 71, 14);
				panel.add(lblFechas);
			}
			{
				cbdia = new JComboBox();
				cbdia.setBounds(113, 124, 60, 20);
				panel.add(cbdia);
			}
			{
				lblHora = new JLabel("Hora:");
				lblHora.setBounds(20, 158, 71, 14);
				panel.add(lblHora);
			}
			{
				cbHora = new JComboBox();
				cbHora.setBounds(113, 155, 60, 20);
				panel.add(cbHora);
			}
			{
				cbMes = new JComboBox();
				cbMes.setBounds(183, 124, 71, 20);
				panel.add(cbMes);
			}
			{
				cbAño = new JComboBox();
				cbAño.setBounds(264, 124, 71, 20);
				panel.add(cbAño);
			}
			{
				cbMinutos = new JComboBox();
				cbMinutos.setBounds(183, 155, 71, 20);
				panel.add(cbMinutos);
			}
			
			JLabel lblAadirCita = new JLabel("A\u00F1adir Cita");
			lblAadirCita.setFont(new Font("Papyrus", Font.PLAIN, 40));
			lblAadirCita.setBounds(10, 11, 222, 47);
			panel.add(lblAadirCita);
			
			JLabel lblCreatedByEsi = new JLabel("created by ESI Conecta \u00A9 Copyright 2013 Todos los derechos reservados. ");
			lblCreatedByEsi.setBounds(30, 179, 363, 14);
			panel.add(lblCreatedByEsi);
			
			JButton btAniadirCita = new JButton("");
			btAniadirCita.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					//persistencia.Cita_BD citaBD = new persistencia.Cita_BD();
					org.ModuleCitas.Cita_BD citaBD = new org.ModuleCitas.Cita_BD();
					
					int numCita = citaBD.getMaxNumCita();
					System.out.println(numCita);
					
					String especialista = cbEspecialista.getSelectedItem().toString();
					int numEspecialista = Integer.parseInt(especialista.split(" ")[0]);
					String paciente = cbPaciente.getSelectedItem().toString();
					int idPac = Integer.parseInt(paciente.split(" ")[0]);
					String dia = cbdia.getSelectedItem().toString();
					String mes = cbMes.getSelectedItem().toString();
					String anio = cbAño.getSelectedItem().toString();
					String fecha = dia.concat("/").concat(mes).concat("/").concat(anio);
					String hora = cbHora.getSelectedItem().toString();
					String min = cbMinutos.getSelectedItem().toString();
					String horaCompleta = hora.concat(":").concat(min);
					
					/*
					dominio.Especialista espe = null;
					dominio.Paciente pac = null;
					*/
					org.ModuleEspecialista.Especialista espe = null;
					org.ModulePacientes.Paciente pac = null;
					try {
						espe = VentanaPrincipal.clasePrincipal.buscar_especialista(numEspecialista);
						pac = VentanaPrincipal.clasePrincipal.buscar_paciente(idPac);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					//dominio.Cita nuevaCita = new dominio.Cita(numCita+1, espe, pac, fecha, horaCompleta);
					Cita nuevaCita = new Cita(numCita+1, espe, pac, fecha, horaCompleta);
					
					try {
						citaBD.Agregar(nuevaCita);
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					VentanaPrincipal.cargarListas();
					VentanaPrincipal.añadirDatosListaCitas();
					frmCrearCita.dispose();
				
				}
			});
			btAniadirCita.setIcon(new ImageIcon(CrerCita.class.getResource("/org/ModulePresentacion/validacion.png")));
			btAniadirCita.setBounds(345, 69, 59, 51);
			panel.add(btAniadirCita);
		}
	}
	
	private void cargarDatos(){
		//cargar datos de especialistas
		for (int i=0;i<VentanaPrincipal.listaEspecialistas.size();i++){
			cbEspecialista.addItem(VentanaPrincipal.listaEspecialistas.get(i).getIdNombreApellido());
		}
		for(int i=0;i<VentanaPrincipal.listaPaciente.size();i++){
			cbPaciente.addItem(VentanaPrincipal.listaPaciente.get(i).getIdNombreApellido());
		}
		for(int i=1;i<32;i++){
			cbdia.addItem(i);
		}
		for(int i=1;i<13;i++){
			cbMes.addItem(i);
		}
		for(int i=2010;i<2020;i++){
			cbAño.addItem(i);
		}
		for(int i=9;i<21;i++){
			cbHora.addItem(i);
		}
		cbMinutos.addItem("00");
		cbMinutos.addItem("30");
		
	}
}
