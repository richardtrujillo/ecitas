package org.ModulePresentacion;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.BorderLayout;

import javax.swing.JTabbedPane;

import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridLayout;

import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.border.TitledBorder;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.JTextArea;
import javax.swing.DefaultComboBoxModel;
import javax.swing.UIManager;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;






import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.SwingConstants;


import javax.swing.JScrollPane;

import java.awt.SystemColor;
import java.awt.Font;
import java.awt.Color;

import javax.swing.ImageIcon;
/*
import persistencia.Cita_BD;
import persistencia.Especialista_BD;
import dominio.*;
*/
import org.ModuleCitas.*;
import org.ModuleEspecialista.*;
import org.ModulePacientes.*;

public class VentanaPrincipal {

	JFrame frmeCitas;
	private JTabbedPane tabbedPane;
	private JPanel pnlCitas;
	private JPanel pnlPacientes;
	private JPanel pnlEspecialistas;
	private JButton btnCrear;
	private JButton btnEliminar;
	private JButton btnCrearEspecialista;
	private JButton btnEliminarEspecialistas;
	private JPanel panel;
	private JTable table;
	
	
	/*
	public static ArrayList<dominio.Paciente> listaPaciente = new ArrayList<dominio.Paciente>();
	public static ArrayList<dominio.Especialista> listaEspecialistas = new ArrayList<dominio.Especialista>();
	public static ArrayList<dominio.Cita> listaCitas = new ArrayList<dominio.Cita>();
	*/
	public static ArrayList<org.ModulePacientes.Paciente> listaPaciente = new ArrayList<org.ModulePacientes.Paciente>();
	public static ArrayList<org.ModuleEspecialista.Especialista> listaEspecialistas = new ArrayList<org.ModuleEspecialista.Especialista>();
	public static ArrayList<org.ModuleCitas.Cita> listaCitas = new ArrayList<org.ModuleCitas.Cita>();
	
	private static JTable tCitas;
	
	public static Principal clasePrincipal = new Principal();
	private JScrollPane scrollPane;
	private static JTable tbEspecialista;
	private JScrollPane scrollPane_1;
	private JScrollPane scrollPane_2;
	private JLabel lblCitas;
	private JLabel lblGestinDePacientes;
	private JLabel lblGestinDeEspecialistas;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					VentanaPrincipal window = new VentanaPrincipal();
					window.frmeCitas.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public VentanaPrincipal() {
		cargarListas();
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmeCitas = new JFrame();
		frmeCitas.getContentPane().setBackground(SystemColor.activeCaption);
		frmeCitas.setTitle("e-citas");
		frmeCitas.setBounds(100, 100, 776, 462);
		frmeCitas.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmeCitas.getContentPane().setLayout(new GridLayout(0, 1, 0, 0));
		{
			tabbedPane = new JTabbedPane(JTabbedPane.TOP);
			tabbedPane.setBackground(SystemColor.activeCaption);
			frmeCitas.getContentPane().add(tabbedPane);
			{
				pnlCitas = new JPanel();
				pnlCitas.setBackground(SystemColor.activeCaption);
				tabbedPane.addTab("Citas", null, pnlCitas, null);
				GridBagLayout gbl_pnlCitas = new GridBagLayout();
				gbl_pnlCitas.columnWidths = new int[]{25, 398, 201, 0, 0};
				gbl_pnlCitas.rowHeights = new int[]{24, 45, 40, 28, 40, 19, 23, 0, 132, 0};
				gbl_pnlCitas.columnWeights = new double[]{0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
				gbl_pnlCitas.rowWeights = new double[]{1.0, 1.0, 0.0, 0.0, 0.0, 1.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
				pnlCitas.setLayout(gbl_pnlCitas);
				{
					{
						lblCitas = new JLabel("Gesti\u00F3n de Citas");
						lblCitas.setFont(new Font("Papyrus", Font.PLAIN, 40));
						GridBagConstraints gbc_lblCitas = new GridBagConstraints();
						gbc_lblCitas.gridheight = 2;
						gbc_lblCitas.gridwidth = 2;
						gbc_lblCitas.insets = new Insets(0, 0, 5, 5);
						gbc_lblCitas.gridx = 0;
						gbc_lblCitas.gridy = 0;
						pnlCitas.add(lblCitas, gbc_lblCitas);
					}
					btnCrear = new JButton("");
					btnCrear.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/org/ModulePresentacion/validacion.png")));
					btnCrear.setBackground(SystemColor.activeCaption);
					btnCrear.setToolTipText("Crear Cita");
					btnCrear.addActionListener(new BtnCrearActionListener());
					GridBagConstraints gbc_btnCrear = new GridBagConstraints();
					gbc_btnCrear.gridheight = 2;
					gbc_btnCrear.anchor = GridBagConstraints.SOUTHEAST;
					gbc_btnCrear.insets = new Insets(0, 0, 5, 5);
					gbc_btnCrear.gridx = 2;
					gbc_btnCrear.gridy = 0;
					pnlCitas.add(btnCrear, gbc_btnCrear);
					{
						btnEliminar = new JButton("");
						btnEliminar.setBackground(SystemColor.activeCaption);
						btnEliminar.setToolTipText("Borrar Cita");
						btnEliminar.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/org/ModulePresentacion/borrar.png")));
						btnEliminar.addActionListener(new ActionListener() {
							public void actionPerformed(ActionEvent arg0) {
								eliminarCita();
							}
						});
						GridBagConstraints gbc_btnEliminar = new GridBagConstraints();
						gbc_btnEliminar.gridheight = 2;
						gbc_btnEliminar.anchor = GridBagConstraints.SOUTHWEST;
						gbc_btnEliminar.insets = new Insets(0, 0, 5, 0);
						gbc_btnEliminar.gridx = 3;
						gbc_btnEliminar.gridy = 0;
						pnlCitas.add(btnEliminar, gbc_btnEliminar);
					}
					{
						{
							scrollPane_2 = new JScrollPane();
							GridBagConstraints gbc_scrollPane_2 = new GridBagConstraints();
							gbc_scrollPane_2.gridwidth = 4;
							gbc_scrollPane_2.gridheight = 7;
							gbc_scrollPane_2.fill = GridBagConstraints.BOTH;
							gbc_scrollPane_2.gridx = 0;
							gbc_scrollPane_2.gridy = 2;
							pnlCitas.add(scrollPane_2, gbc_scrollPane_2);
							tCitas = new JTable();
							scrollPane_2.setViewportView(tCitas);
							tCitas.setToolTipText("");
							tCitas.setModel(new DefaultTableModel(
								new Object[][] {
								},
								new String[] {
									"Numero", "Especialista", "Paciente", "Fecha", "Hora"
								}
							) {
								Class[] columnTypes = new Class[] {
									Object.class, String.class, String.class, String.class, String.class
								};
								public Class getColumnClass(int columnIndex) {
									return columnTypes[columnIndex];
								}
							});
							tCitas.getColumnModel().getColumn(0).setPreferredWidth(50);
							tCitas.getColumnModel().getColumn(0).setMaxWidth(50);
							tCitas.getColumnModel().getColumn(3).setResizable(false);
							tCitas.getColumnModel().getColumn(3).setPreferredWidth(60);
							tCitas.getColumnModel().getColumn(3).setMaxWidth(60);
							tCitas.getColumnModel().getColumn(4).setResizable(false);
							tCitas.getColumnModel().getColumn(4).setPreferredWidth(52);
							tCitas.getColumnModel().getColumn(4).setMaxWidth(52);
						}
					}
				}
			}
			{
				pnlPacientes = new JPanel();
				pnlPacientes.setBackground(SystemColor.activeCaption);
				tabbedPane.addTab("Pacientes", null, pnlPacientes, null);
				GridBagLayout gbl_pnlPacientes = new GridBagLayout();
				gbl_pnlPacientes.columnWidths = new int[]{0, 0};
				gbl_pnlPacientes.rowHeights = new int[]{0, 0, 0, 0, 206, 0, 0, 0};
				gbl_pnlPacientes.columnWeights = new double[]{1.0, Double.MIN_VALUE};
				gbl_pnlPacientes.rowWeights = new double[]{1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 1.0, Double.MIN_VALUE};
				pnlPacientes.setLayout(gbl_pnlPacientes);
				{
					lblGestinDePacientes = new JLabel("Gesti\u00F3n de Pacientes");
					lblGestinDePacientes.setFont(new Font("Papyrus", Font.PLAIN, 40));
					GridBagConstraints gbc_lblGestinDePacientes = new GridBagConstraints();
					gbc_lblGestinDePacientes.gridheight = 2;
					gbc_lblGestinDePacientes.insets = new Insets(0, 0, 5, 0);
					gbc_lblGestinDePacientes.gridx = 0;
					gbc_lblGestinDePacientes.gridy = 0;
					pnlPacientes.add(lblGestinDePacientes, gbc_lblGestinDePacientes);
				}
				{
					panel = new JPanel();
					panel.setBackground(SystemColor.activeCaption);
					panel.setBorder(new TitledBorder(null, "Listado de Pacientes", TitledBorder.LEADING, TitledBorder.TOP, null, null));
					GridBagConstraints gbc_panel = new GridBagConstraints();
					gbc_panel.gridheight = 5;
					gbc_panel.fill = GridBagConstraints.BOTH;
					gbc_panel.gridx = 0;
					gbc_panel.gridy = 2;
					pnlPacientes.add(panel, gbc_panel);
					GridBagLayout gbl_panel = new GridBagLayout();
					gbl_panel.columnWidths = new int[]{265, 0};
					gbl_panel.rowHeights = new int[]{80, 0, 0};
					gbl_panel.columnWeights = new double[]{1.0, Double.MIN_VALUE};
					gbl_panel.rowWeights = new double[]{1.0, 1.0, Double.MIN_VALUE};
					panel.setLayout(gbl_panel);
					{
						scrollPane_1 = new JScrollPane();
						GridBagConstraints gbc_scrollPane_1 = new GridBagConstraints();
						gbc_scrollPane_1.gridheight = 2;
						gbc_scrollPane_1.fill = GridBagConstraints.BOTH;
						gbc_scrollPane_1.gridx = 0;
						gbc_scrollPane_1.gridy = 0;
						panel.add(scrollPane_1, gbc_scrollPane_1);
						{
							table = new JTable();
							table.setBackground(SystemColor.text);
							scrollPane_1.setViewportView(table);
							table.setModel(new DefaultTableModel(
								new Object[][] {
								},
								new String[] {
									"Codigo", "Nombre", "Apellidos"
								}
							) {
								Class[] columnTypes = new Class[] {
									Integer.class, String.class, String.class
								};
								public Class getColumnClass(int columnIndex) {
									return columnTypes[columnIndex];
								}
								boolean[] columnEditables = new boolean[] {
									false, false, false
								};
								public boolean isCellEditable(int row, int column) {
									return columnEditables[column];
								}
							});
							table.getColumnModel().getColumn(0).setResizable(false);
							table.getColumnModel().getColumn(0).setMaxWidth(75);
						}
					}
				}
			}
			{
				pnlEspecialistas = new JPanel();
				pnlEspecialistas.setBackground(SystemColor.activeCaption);
				tabbedPane.addTab("Especialistas", null, pnlEspecialistas, null);
				GridBagLayout gbl_pnlEspecialistas = new GridBagLayout();
				gbl_pnlEspecialistas.columnWidths = new int[]{0, 0, 0};
				gbl_pnlEspecialistas.rowHeights = new int[]{45, 0, 0, 0, 0, 0};
				gbl_pnlEspecialistas.columnWeights = new double[]{0.0, 1.0, Double.MIN_VALUE};
				gbl_pnlEspecialistas.rowWeights = new double[]{0.0, 0.0, 0.0, 0.0, 1.0, Double.MIN_VALUE};
				pnlEspecialistas.setLayout(gbl_pnlEspecialistas);
				{
					btnCrearEspecialista = new JButton("Crear");
					btnCrearEspecialista.setBackground(SystemColor.activeCaption);
					btnCrearEspecialista.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/org/ModulePresentacion/validacion.png")));
					btnCrearEspecialista.addActionListener(new BtnCrearEspecialistaActionListener());
					{
						lblGestinDeEspecialistas = new JLabel("Gesti\u00F3n de Especialistas");
						lblGestinDeEspecialistas.setFont(new Font("Papyrus", Font.PLAIN, 40));
						GridBagConstraints gbc_lblGestinDeEspecialistas = new GridBagConstraints();
						gbc_lblGestinDeEspecialistas.gridwidth = 2;
						gbc_lblGestinDeEspecialistas.insets = new Insets(0, 0, 5, 5);
						gbc_lblGestinDeEspecialistas.gridx = 0;
						gbc_lblGestinDeEspecialistas.gridy = 0;
						pnlEspecialistas.add(lblGestinDeEspecialistas, gbc_lblGestinDeEspecialistas);
					}
					GridBagConstraints gbc_btnCrearEspecialista = new GridBagConstraints();
					gbc_btnCrearEspecialista.fill = GridBagConstraints.BOTH;
					gbc_btnCrearEspecialista.insets = new Insets(0, 0, 5, 5);
					gbc_btnCrearEspecialista.gridx = 0;
					gbc_btnCrearEspecialista.gridy = 1;
					pnlEspecialistas.add(btnCrearEspecialista, gbc_btnCrearEspecialista);
				}
				{
					scrollPane = new JScrollPane();
					GridBagConstraints gbc_scrollPane = new GridBagConstraints();
					gbc_scrollPane.gridheight = 4;
					gbc_scrollPane.fill = GridBagConstraints.BOTH;
					gbc_scrollPane.gridx = 1;
					gbc_scrollPane.gridy = 1;
					pnlEspecialistas.add(scrollPane, gbc_scrollPane);
					{
						tbEspecialista = new JTable();
						tbEspecialista.setBackground(Color.WHITE);
						tbEspecialista.setModel(new DefaultTableModel(
							new Object[][] {
							},
							new String[] {
								"N. Colegiado", "Nombre", "Apellidos", "DNI", "Especialidad", "E-mail", "N. Consulta"
							}
						));
						scrollPane.setViewportView(tbEspecialista);
					}
				}
				{
					btnEliminarEspecialistas = new JButton("Eliminar");
					btnEliminarEspecialistas.setBackground(SystemColor.activeCaption);
					btnEliminarEspecialistas.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/org/ModulePresentacion/borrar.png")));
					btnEliminarEspecialistas.addActionListener(new BtnEliminarEspecialistasActionListener());
					GridBagConstraints gbc_btnEliminarEspecialistas = new GridBagConstraints();
					gbc_btnEliminarEspecialistas.insets = new Insets(0, 0, 5, 5);
					gbc_btnEliminarEspecialistas.gridx = 0;
					gbc_btnEliminarEspecialistas.gridy = 2;
					pnlEspecialistas.add(btnEliminarEspecialistas, gbc_btnEliminarEspecialistas);
				}
			}
		}
		añadirDatosListaPacientes();
		añadirDatosListaEspecialistas();
		añadirDatosListaCitas();
	}
	private class BtnCrearActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			if(listaEspecialistas.size()==0){
				JOptionPane.showMessageDialog(null, "No puede crear citas si no hay especialistas en el sistema.", "Error", JOptionPane.ERROR_MESSAGE);
			}else{
				CrerCita window=new CrerCita();
				window.frmCrearCita.setVisible(true);
			}
		}
	}
	private class BtnCrearEspecialistaActionListener implements ActionListener {
		public void actionPerformed(ActionEvent e) {
			Especialista window= new Especialista();
			window.frmEspecialista.setVisible(true);
		}
	}
	private class BtnEliminarEspecialistasActionListener implements ActionListener {
		public void actionPerformed(ActionEvent arg0) {
			int columna = tbEspecialista.getSelectedColumn();
			int fila = tbEspecialista.getSelectedRow();
			if (columna == -1 || fila == -1){
				JOptionPane.showMessageDialog(null, "Debe seleccionar un Especialista en concreto para eliminarlo.", "Error", JOptionPane.ERROR_MESSAGE);
			}
			else{
				int reply = JOptionPane.showConfirmDialog(null, "�Est� seguro de que desea eliminar el especialista seleccionado?", "Atencion",  JOptionPane.YES_NO_OPTION);
				if (reply == JOptionPane.YES_OPTION)
				{
					String numEspecialista = tbEspecialista.getValueAt(tbEspecialista.getSelectedRow(), 0).toString();
					int numeroEspecialista = Integer.parseInt(numEspecialista);
					
					Especialista_BD borrarEspecialista = new Especialista_BD();
					
					try {
						//dominio.Especialista espeBorrar = clasePrincipal.buscar_especialista(numeroEspecialista);
						org.ModuleEspecialista.Especialista espeBorrar = clasePrincipal.buscar_especialista(numeroEspecialista);
						borrarEspecialista.Borrar_especialista(espeBorrar);
						cargarListas();
						añadirDatosListaEspecialistas();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					} catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public static void cargarListas(){
		try {
			/*
			listaCitas=new ArrayList<dominio.Cita>();
			listaEspecialistas=new ArrayList<dominio.Especialista>();
			listaPaciente=new ArrayList<dominio.Paciente>();
			*/
			listaCitas=new ArrayList<org.ModuleCitas.Cita>();
			listaEspecialistas=new ArrayList<org.ModuleEspecialista.Especialista>();
			listaPaciente=new ArrayList<org.ModulePacientes.Paciente>();
			try{
				Thread.currentThread().sleep(2000);
			}catch(Exception e){
				
			}
			listaEspecialistas = clasePrincipal.listar_especialistas();
			listaPaciente = clasePrincipal.listar_pacientes();
			listaCitas = clasePrincipal.listar_citas();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	private void añadirDatosListaPacientes(){
		//cargarListas();
		//DefaultTableModel modelo= new DefaultTableModel();
		DefaultTableModel modelo = (DefaultTableModel)table.getModel();
		table.removeAll();
		for (int i=0;i< listaPaciente.size();i++){
			Object[]fila=new Object[10];
			fila[0]=listaPaciente.get(i).getIdPaciente();
			fila[1]=listaPaciente.get(i).getNombre();
			fila[2]=listaPaciente.get(i).getApellido();
			modelo.addRow(fila);
		}

		table.setModel(modelo);
	}
	
	public static void añadirDatosListaEspecialistas() {
		//cargarListas();
		
		DefaultTableModel modelo  = (DefaultTableModel)tbEspecialista.getModel();
		
		modelo.setRowCount(0);
		//"N. Colegiado", "Nombre", "Apellidos", "DNI", "Especialidad", "E-mail", "N. Consulta"
		for (int i=0;i< listaEspecialistas.size();i++){
			Object[]fila=new Object[10];
			fila[0]=listaEspecialistas.get(i).getN_colegiado();
			fila[1]=listaEspecialistas.get(i).getNombre();
			fila[2]=listaEspecialistas.get(i).getApellidos();
			fila[3]=listaEspecialistas.get(i).getDni();
			fila[4]=listaEspecialistas.get(i).getEspecialidad();
			fila[5]=listaEspecialistas.get(i).getEmail();
			fila[6]=listaEspecialistas.get(i).getN_consulta();
			
			modelo.addRow(fila);
		}
		
		tbEspecialista.setModel(modelo);
	}
	
	public static void añadirDatosListaCitas(){
		//cargarListas();
		tCitas.removeAll();
		
		DefaultTableModel modelo = (DefaultTableModel)tCitas.getModel();
		modelo.setRowCount(0);
		for (int i=0;i< listaCitas.size();i++){
			Object[]fila=new Object[10];
			
			fila[0]=listaCitas.get(i).getCita_num();
			fila[1]=listaCitas.get(i).getEspecialista().getIdNombreApellido();
			fila[2]=listaCitas.get(i).getPaciente().getIdNombreApellido();
			
			String fechaCompleta = listaCitas.get(i).getFecha();
			fila[3]=fechaCompleta;
			
			String horaCompleta = listaCitas.get(i).getHora();
			fila[4]=horaCompleta;
			modelo.addRow(fila);
			
		}

		tCitas.setModel(modelo);
	}
	
	private void eliminarCita(){
		if(tCitas.getSelectedRow() == -1){
			JOptionPane.showMessageDialog(null, "Debe seleccionar una cita en concreto para eliminarla.", "Error", JOptionPane.ERROR_MESSAGE);
		}else{
			int reply = JOptionPane.showConfirmDialog(null, "�Est� seguro de que desea eliminar la cita?", "Atencion",  JOptionPane.YES_NO_OPTION);
			if (reply == JOptionPane.YES_OPTION)
			{

				int idCita = Integer.parseInt(tCitas.getValueAt(tCitas.getSelectedRow(), 0).toString()); 
				
				Cita_BD citaBD = new Cita_BD();
				
				//dominio.Cita citaBorrar;
				
				try {
					org.ModuleCitas.Cita citaBorrar = clasePrincipal.buscar_cita(idCita);
					//citaBorrar = clasePrincipal.buscar_cita(idCita);
					citaBD.Borrar_cita(citaBorrar);
					cargarListas();
					añadirDatosListaCitas();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			
		}
	}
}