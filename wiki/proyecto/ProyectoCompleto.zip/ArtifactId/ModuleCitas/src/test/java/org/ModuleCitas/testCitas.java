package org.ModuleCitas;

import org.ModuleEspecialista.Especialista;
import org.ModulePacientes.Paciente;
import org.junit.Test;

import junit.framework.TestCase;

public class testCitas extends TestCase {

	@Test
	public void testCitas1() {
		Agente agente = new Agente();
		Agente instancia = agente.getInstancia();
		//Integer.MIN_VALUE sirve para representar el error
		assertNotNull("Obtenida al instancia" ,instancia== new Agente());
	}
	
	@Test
	public void testCitas2() {
		Agente agente = new Agente();
		boolean funciona = false;
		try{
			agente.conectar();
			funciona=true;
		}catch(Exception e){
			funciona=false;
		}
		//Integer.MIN_VALUE sirve para representar el error
		assertTrue("Conectado a la BD" , funciona==Boolean.TRUE);
	}
	
	@Test
	public void testCitas3() {
		Agente agente = new Agente();
		boolean funciona = false;
		try{
			agente.desconectar();
			funciona=true;
		}catch(Exception e){
			funciona=false;
		}
		//Integer.MIN_VALUE sirve para representar el error
		assertTrue("Desconectado de la BD" , funciona==Boolean.TRUE);
	}
	
	@Test
	public void testCitas4 (){
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		
		assertNotNull(c);
	
	}
	
	@Test
	public void testCitas5(){
		
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		int num_cita= c.getCita_num();
		assertEquals( c.getCita_num(), num_cita);
	}
	
	@Test
	public void testCitas6(){
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		String fecha= c.getFecha();
		assertEquals(c.getFecha(), fecha);
	}
	
	@Test
	public void testCitas7(){
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		String hora= c.getHora();
		assertEquals(c.getHora(), hora);
	}
	
	
	@Test
	public void testCitas8(){
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		String esp= c.get_esp();
		assertEquals(c.get_esp(), esp);
	}
	
	@Test
	public void testCitas9(){
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		String pac=c.get_pa();
		assertEquals(c.get_pa(), pac);
	}
	
	@Test
	public void testCitas10(){
		Especialista e = new Especialista(1, "a", "b", "c", "d", "e", 2);
		Paciente p = new Paciente(1, "a", "b", "c", "d");
		Cita c = new Cita(1,e,p,"c","d");
		int cita=c.getCita_num();
		assertEquals(c.getCita_num(), cita);
	}
}
