package org.ModuleCitas;

import java.sql.SQLException;

//import persistencia.Cita_BD;
import org.ModuleEspecialista.*;
import org.ModulePacientes.*;

public class Cita {
	private int Cita_num;
	private org.ModuleEspecialista.Especialista Especialista;
	private org.ModulePacientes.Paciente paciente;
	private String fecha;
	private String hora;
	private Cita_BD gestor_citasBD=new Cita_BD();
	
	
	//para pruebas, BORRAR
	private String e,p;
	
	public String get_esp(){
		return e;
	}
	public String get_pa(){
		return p;
	}
	public Cita(int cita_num, String especialista,String paciente, String fecha, String hora) {
		Cita_num = cita_num;
		this.e= especialista;
		this.p = paciente;
		this.fecha = fecha;
		this.hora = hora;
	}
	/// borrarrrrrrrr
	
	
	
	public Cita_BD getGestor_citasBD() {
		return gestor_citasBD;
	}
	public void setGestor_citasBD(Cita_BD gestor_citasBD) {
		this.gestor_citasBD = gestor_citasBD;
	}
	public Cita(int cita_num, Especialista especialista,Paciente paciente, String fecha, String hora) {
		Cita_num = cita_num;
		Especialista = especialista;
		this.paciente = paciente;
		this.fecha = fecha;
		this.hora = hora;
	}

	

	public Cita Buscar(Paciente paciente){
		return null;
				
	}
	public void Borrar(int CitaNum) throws SQLException, Exception{
		this.Cita_num=CitaNum;
		this.gestor_citasBD.Borrar_cita(this);
		
	}
	public void Agregar(int CitaNum) throws Exception{
		this.Cita_num=CitaNum;
		this.gestor_citasBD.Agregar(this);
	}
	

	
	//get y set de Cita
	public int getCita_num() {
		return Cita_num;
	}
	public void setCita_num(int cita_num) {
		Cita_num = cita_num;
	}
	public Especialista getEspecialista() {
		return Especialista;
	}
	public void setEspecialista(Especialista especialista) {
		Especialista = especialista;
	}
	public Paciente getPaciente() {
		return paciente;
	}
	public void setPaciente(Paciente paciente) {
		this.paciente = paciente;
	}
	public String getFecha() {
		return fecha;
	}
	public void setFecha(String fecha) {
		this.fecha = fecha;
	}
	public String getHora() {
		return hora;
	}
	public void setHora(String hora) {
		this.hora = hora;
	}
	
	
}
