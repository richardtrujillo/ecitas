package org.ModuleCitas;

import java.util.ArrayList;

import org.ModuleEspecialista.*;
import org.ModulePacientes.*;

public class Principal {
	
	ArrayList<Paciente> lista_pacientes=new ArrayList<Paciente>();
	
	ArrayList<Cita> lista_citas=new ArrayList<Cita>();
	
	ArrayList<Especialista> lista_especialistas=new ArrayList<Especialista>();
	String login;
	String password;
	
	
	//lista_pacientes=new ArrayList(listar_citas());
	
	
	/*public ArrayList<String> listar_pacientes(){
		return lista_pacientes;
		
	}*/
	
	
	
	/*public ArrayList<String> listar_especialistas(){
		return lista_especialistas;
	}*/
/*	public void cambiarContrasena(String nuevopassword){
		password=nuevopassword;
	}*/
	
	
	public ArrayList<Especialista> listar_especialistas() throws Exception{
		lista_especialistas=new ArrayList <Especialista>();
		Especialista_BD e=new Especialista_BD();
		lista_especialistas=e.Listar_Todos();
		return lista_especialistas;
	}

	public ArrayList<Cita> listar_citas() throws Exception {
		lista_citas=new ArrayList <Cita>();
		Cita_BD cita1=new Cita_BD();
		lista_citas=cita1.Listar_Todos();
		return lista_citas;
	}

	public ArrayList<Paciente> listar_pacientes()throws Exception{
		lista_pacientes=new ArrayList <Paciente>();
		Paciente_BD pa=new Paciente_BD();
		lista_pacientes=pa.Listar_Todos();
		return lista_pacientes;
	}
	
	public Especialista buscar_especialista(int n_col) throws Exception{
		Boolean seguir=true;
		Especialista e=null;
		this.listar_especialistas();
		for (int i=0;i<lista_especialistas.size() && seguir; i++){
			e=lista_especialistas.get(i);
			if (n_col==e.getN_colegiado()){
				seguir=false;
			}
		}
		if (seguir==true) e=null;
		
		return e;
	}
	public Cita buscar_cita(int cita_n) throws Exception{
		Boolean seguir=true;
		Cita c=null;
		//this.listar_citas();
		for (int i=0;i<lista_citas.size() && seguir; i++){
			c=lista_citas.get(i);
			if (cita_n==c.getCita_num()){
				seguir=false;
			}
		}
		if (seguir==true) c=null;
		
		return c;
	}
	public Paciente buscar_paciente(int id) throws Exception{
		Boolean seguir=true;
		Paciente p=null;
		//this.listar_pacientes();
		for (int i=0;i<lista_pacientes.size() && seguir; i++){
			p=lista_pacientes.get(i);
			if (id==p.getIdPaciente()){
				seguir=false;
			}
		}
		if (seguir==true) p=null;
		
		return p;
	}
}
