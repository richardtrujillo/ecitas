package org.ModuleCitas;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

/*
import dominio.Agente;
import dominio.Cita;
import dominio.Especialista;
import dominio.Paciente;
import dominio.Principal;
*/

import org.ModuleEspecialista.*;
import org.ModulePacientes.*;


public class Cita_BD {
	Agente agente=new Agente();
	private ArrayList<Cita> lista_citas=new ArrayList<Cita>();
	
	public ArrayList<Cita> getLista_citas() {
		return lista_citas;
	}


	public void Agregar(Cita cita) throws Exception{
		
		Boolean s=true;
		agente.conectar();
		agente=Agente.getInstancia();
		//Listar_Todos();

 
		try{
			String sql = "INSERT INTO Citas (Cita_num,Especialista,Paciente,Fecha,Hora) VALUES("+cita.getCita_num()+","+cita.getEspecialista().getN_colegiado()+","+ cita.getPaciente().getIdPaciente()+",'"+cita.getFecha()+"','"+cita.getHora()+"');";
			agente.create(sql);
			agente.desconectar();
		}
		catch(ClassNotFoundException | SQLException e){
			System.out.println(e);
			//JOptionPane.showMessageDialog(null,"Error al añadir en la Base de datos.","Error",JOptionPane.INFORMATION_MESSAGE);
		}

		lista_citas.add(cita);
	}


	public ArrayList<Cita> Listar_Todos() throws Exception {
		ResultSet BD;
		Principal prin = new Principal();
		prin.listar_especialistas();
		prin.listar_pacientes();
		//Cita citabd;
		Cita c;
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			BD=agente.read("SELECT * FROM Citas ORDER BY Cita_num");

			
			if(BD!=null){
				while (BD.next()){
					//for(int i=1;i<=BD.getMetaData().getColumnCount();i++)
					int num=Integer.parseInt(BD.getString("Cita_num"));
					int especialista = Integer.parseInt(BD.getString("Especialista"));
					Especialista e=prin.buscar_especialista(especialista);
					Paciente p=prin.buscar_paciente(Integer.parseInt(BD.getString("Paciente")));
					c=new Cita(num,e,p,BD.getString("FECHA"),BD.getString("Hora"));
					lista_citas.add(c);
				}
				BD.close();				
			}
			agente.desconectar();
		}catch(SQLException e){
			System.out.println("hubo un error");
			System.out.println(e);
		}
		
		return lista_citas;
	}

	public void Borrar_cita(Cita cita1) throws SQLException, Exception {
		
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			agente.delete("DELETE FROM Citas WHERE Cita_num="+cita1.getCita_num()+";");
			agente.desconectar();
		}catch (Exception e){
			System.out.println("Error al eliminar");
		}
		
		
	}
	
	public int getMaxNumCita(){
		ResultSet BD;
		int numCitaMax = 0;
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			
			BD = agente.read("SELECT MAX(Cita_num) as numero FROM Citas;");
			
			if(BD!=null)
				while(BD.next()){
					numCitaMax = Integer.parseInt(BD.getString("numero"));
					System.out.println("NUMERO DE CITA RECIBIDO: "+numCitaMax);
				}
			BD.close();
			agente.desconectar();				
		}catch(Exception e){
			JOptionPane.showMessageDialog(null,"Error al añadir en la Base de datos.","Error",JOptionPane.INFORMATION_MESSAGE);
		}
		
		return numCitaMax;
		
	}
	
	
	public void desconectar(){
		
		try{
			
			agente.desconectar();
			
		}catch(Exception e){
			System.out.println("Error de desconexion");
		}
	}
	
	///borrar
	public void listar_todos(){
		for (int i=0;i<lista_citas.size();i++){
			System.out.println(lista_citas.get(i).getCita_num());
		}
	}

}

