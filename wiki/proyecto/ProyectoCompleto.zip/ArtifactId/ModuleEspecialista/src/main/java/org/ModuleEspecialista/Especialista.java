package org.ModuleEspecialista;
/*
import persistencia.Especialista_BD;
*/
public class Especialista {
	private int n_colegiado;
	private String dni;
	private String nombre;
	private String apellidos;
	private String especialidad;
	private String email;
	private int n_consulta;
	
	Especialista_BD especialistaBD = new Especialista_BD();
	
	public Especialista(int n_colegiado, String dni, String nombre,
			String apellidos, String especialidad, String email, int n_consulta) {
		super();
		this.setN_colegiado(n_colegiado);
		this.setDni(dni);
		this.setNombre(nombre);
		this.setApellidos(apellidos);
		this.setEspecialidad(especialidad);
		this.setEmail(email);
		this.setN_consulta(n_consulta);
	}
	
	
	public void borrar(int n_colegiado){
		
	}
	
	public int getN_colegiado() {
		return n_colegiado;
	}
	public void setN_colegiado(int n_colegiado) {
		this.n_colegiado = n_colegiado;
	}
	public String getDni() {
		return dni;
	}
	public void setDni(String dni) {
		this.dni = dni;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellidos() {
		return apellidos;
	}
	public void setApellidos(String apellidos) {
		this.apellidos = apellidos;
	}
	public String getEspecialidad() {
		return especialidad;
	}
	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getN_consulta() {
		return n_consulta;
	}
	public void setN_consulta(int n_consulta) {
		this.n_consulta = n_consulta;
	}
	
	public String getIdNombreApellido(){
		return Integer.toString(this.getN_colegiado()) +" "+ this.getNombre()+" "+this.getApellidos();
	}
	
}
