package org.ModuleEspecialista;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;
/*
import dominio.Agente;
import dominio.Especialista;
*/
public class Especialista_BD {
	Agente agente=new Agente();
	private ArrayList<Especialista> lista_especialistas=new ArrayList<Especialista>();
	
	public void Agregar(Especialista e) throws Exception{
		
		Boolean s=true;
		agente.conectar();
		agente=Agente.getInstancia();
		//cita.listarTodo();
		

		
		if (s){ 
			try{
				agente.create("INSERT INTO Especialistas(N_Colegiado,DNI,Nombre,Apellidos,Especialidad,Email,Numero_Consulta) VALUES("+e.getN_colegiado()+",'"+e.getDni()+"','"+ e.getNombre()+"','"+e.getApellidos()+"','"+e.getEspecialidad()+"','"+e.getEmail()+"',"+e.getN_consulta()+");");
				agente.desconectar();
			}
			catch(ClassNotFoundException | SQLException ex){
				System.out.println(ex);
				JOptionPane.showMessageDialog(null,"Error al añadir en la Base de datos.","Error",JOptionPane.INFORMATION_MESSAGE);
			}

			lista_especialistas.add(e);
		}
		

		
	}
	
	public ArrayList<Especialista> Listar_Todos() throws Exception {
		ResultSet BD;
		//Cita citabd;
		Especialista e;
		lista_especialistas=new ArrayList<Especialista>();
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			BD=agente.read("SELECT * FROM Especialistas ORDER BY N_Colegiado");


			if(BD!=null){
				while (BD.next()){
					//for(int i=1;i<=BD.getMetaData().getColumnCount();i++)
					
					
					e=new Especialista(Integer.parseInt(BD.getString("N_Colegiado")),BD.getString("DNI"),BD.getString("Nombre"),BD.getString("Apellidos"),BD.getString("Especialidad"),BD.getString("Email"),Integer.parseInt(BD.getString("Numero_Consulta")));
					lista_especialistas.add(e);
					//System.out.println(lista_citas.get(i-1));

				}
				BD.close();
				
			}
			
			agente.desconectar();
		}catch(SQLException ex){
			System.out.println("hubo un error en especialista");
			System.out.println(ex);
				
		}
		
		return lista_especialistas;
	}
	public void Borrar_especialista(Especialista esp) throws SQLException, Exception {
		
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			
			agente.delete("DELETE FROM Especialistas WHERE N_colegiado="+esp.getN_colegiado()+";");
			agente.desconectar();
		}catch (Exception e){
			System.out.println("Error al eliminar");
		}
		
		
	}
	
	public void modificiar_especialista(Especialista es)throws Exception {
		//agente.update("UPDATE G�neros SET descGenero='" & frm_GestionarDatos.txt_gd_gen.Text & "'WHERE IdGenero=" & gen.midGenero & ";")
	
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			
			agente.update("UPDATE Especialistas SET Nombre='"+es.getNombre()+"', Apellidos='"+es.getApellidos()+"', Especialidad='"+es.getEspecialidad()+"', Email='"+es.getEmail()+"', Numero_Consulta="+es.getN_consulta()+" where N_Colegiado="+es.getN_colegiado()+";");
			agente.desconectar();
		}catch(Exception e){
			System.out.println(e);
			JOptionPane.showMessageDialog(null,"Error al añadir en la Base de datos.","Error",JOptionPane.INFORMATION_MESSAGE);
		}
	
	}
	
	public void listar_todos(){
		for (int i=0;i<lista_especialistas.size();i++){
			System.out.println(lista_especialistas.get(i).getN_colegiado());
		}
	}
}
