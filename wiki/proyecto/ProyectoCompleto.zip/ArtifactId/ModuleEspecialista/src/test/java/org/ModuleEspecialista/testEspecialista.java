package org.ModuleEspecialista;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import junit.framework.TestCase;

public class testEspecialista extends TestCase {
	
	@Test
	public void testEspecialista1() {
		Agente agente = new Agente();
		Agente instancia = agente.getInstancia();
		//Integer.MIN_VALUE sirve para representar el error
		assertNotNull("Obtenida al instancia" ,instancia== new Agente());
	}
	
	@Test
	public void testEspecialista2() {
		Agente agente = new Agente();
		boolean funciona = false;
		try{
			agente.conectar();
			funciona=true;
		}catch(Exception e){
			funciona=false;
		}
		//Integer.MIN_VALUE sirve para representar el error
		assertTrue("Conectado a la BD" , funciona==Boolean.TRUE);
	}
	
	@Test
	public void testEspecialista3() {
		Agente agente = new Agente();
		boolean funciona = false;
		try{
			agente.desconectar();
			funciona=true;
		}catch(Exception e){
			funciona=false;
		}
		//Integer.MIN_VALUE sirve para representar el error
		assertTrue("Desconectado de la BD" , funciona==Boolean.TRUE);
	}
	
	@Test
	public void testEspecialista4 (){
		Especialista p = new Especialista(1,"a","a","a","a", "a", 1);
		
		assertNotNull(p);
	}
	
	@Test
	public void testEspecialista5(){
		Especialista p = new Especialista(1, "a", "b", "c", "d", "e", 2);
		int numColegiado = p.getN_colegiado();
		assertEquals(p.getN_colegiado(), numColegiado);
	}
	
	@Test
	public void testEspecialista6(){
		Especialista p = new Especialista(1, "a", "b", "c", "d", "e", 2);
		String nombre = p.getNombre();
		assertEquals(p.getNombre(), nombre);
	}
	
	@Test
	public void testEspecialista7(){
		Especialista p = new Especialista(1, "a", "b", "c", "d", "e", 2);
		String apellidos = p.getApellidos();
		assertEquals(p.getApellidos(), apellidos);
	}
	
	
}
