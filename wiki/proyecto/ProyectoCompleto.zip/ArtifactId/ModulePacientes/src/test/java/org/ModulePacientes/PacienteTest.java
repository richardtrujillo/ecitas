package org.ModulePacientes;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.junit.Test;

import junit.framework.TestCase;

public class PacienteTest extends TestCase {
	
	@Test
	public void testAgente1() {
		Agente agente = new Agente();
		Agente instancia = agente.getInstancia();
		//Integer.MIN_VALUE sirve para representar el error
		assertNotNull("Obtenida al instancia" ,instancia== new Agente());
	}
	
	@Test
	public void testAgente2() {
		Agente agente = new Agente();
		boolean funciona = false;
		try{
			agente.conectar();
			funciona=true;
		}catch(Exception e){
			funciona=false;
		}
		//Integer.MIN_VALUE sirve para representar el error
		assertTrue("Conectado a la BD" , funciona==Boolean.TRUE);
	}
	
//	@Test
//	public void testAgente3() {
//		Agente agente = new Agente();
//		boolean funciona = false;
//		try{
//			agente.desconectar();
//			funciona=true;
//		}catch(Exception e){
//			funciona=false;
//		}
//		//Integer.MIN_VALUE sirve para representar el error
//		assertTrue("Desconectado de la BD" , funciona==Boolean.TRUE);
//	}
	
	@Test
	public void testAgente4 (){
		Paciente p = new Paciente(1,"a","a","a","a");
		
		assertNotNull(p);
	}
	
	
	@Test
	public void testAgente5(){
		Paciente p = new Paciente(1,"a","a","a","a");
		String apellido=p.getApellido();
		assertEquals(p.getApellido(), apellido);
	}
	
	@Test
	public void testAgente6(){
		Paciente p = new Paciente(1,"a","a","a","a");
		String dni=p.getDni();
		assertEquals(p.getDni(),dni);
	}
}
