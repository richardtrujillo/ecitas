package org.ModulePacientes;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.swing.JOptionPane;
/*
import dominio.Agente;
import dominio.Paciente;
*/
public class Paciente_BD {
	Agente agente=new Agente();
	private ArrayList<Paciente> lista_pacientes=new ArrayList<Paciente>();
	
	
	
	
	public ArrayList<Paciente> Listar_Todos() throws Exception {
		lista_pacientes=new ArrayList<Paciente>();
		ResultSet BD;
		//Cita citabd;
		Paciente p;
		try{
			agente.conectar();
			agente=Agente.getInstancia();
			BD=agente.read("SELECT * FROM Pacientes ORDER BY IdPaciente");

			if(BD!=null){
				while (BD.next()){
					p=new Paciente(Integer.parseInt(BD.getString("IdPaciente")),BD.getString("Nombre"),BD.getString("Apellidos"),"","");
					lista_pacientes.add(p);
				}
			}
			BD.close();
			agente.desconectar();
		}catch(SQLException e){
			System.out.println("Hubo un error en pacientes");
			System.out.println(e);
		}
		return lista_pacientes;
	}
	

	
	public void desconectar(){
		
		try{
			
			agente.desconectar();
			
		}catch(Exception e){
			System.out.println("Error de desconexion");
		}
	}
	
	///borrar
	public void listar_todos(){
		for (int i=0;i<lista_pacientes.size();i++){
			System.out.println(lista_pacientes.get(i).getIdPaciente());
		}
	}
	
}
