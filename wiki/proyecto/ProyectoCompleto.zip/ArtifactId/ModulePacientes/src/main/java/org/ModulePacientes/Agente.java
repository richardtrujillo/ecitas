package org.ModulePacientes;

import java.sql.*;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JOptionPane;


public class Agente {
    protected static Agente mInstancia=null;
    protected static Connection miConexionBD;
    Statement sentencia;//Variable para ejecutar las diferentes concultas SQL
    
    final static String driver="sun.jdbc.odbc.JdbcOdbcDriver";
    final static String url="jdbc:odbc:BDecitas";
    //Constructor
    public Agente(){/*TO DO*/}
    
    //Implementaci�n del patr�n Singleton
    public static Agente getInstancia(){
          if (mInstancia==null){
          mInstancia=new Agente();
        }
        return mInstancia;
     }
     
    @SuppressWarnings("unused")
	public void conectar() throws Exception {       
         try{
        	 Class.forName(driver);
        	 miConexionBD=DriverManager.getConnection(url);
        	 sentencia = miConexionBD.createStatement();
         }catch(ClassNotFoundException | SQLException e){
             System.out.println(e);
             JOptionPane.showMessageDialog(null,"Error al añadir en la Base de datos.","Error",JOptionPane.INFORMATION_MESSAGE);}
    }

   

   
   public void desconectar() {//perfecto
   	try {
   		this.miConexionBD.close();
   		System.out.println("hemos cerrado la base de datos");
   	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}}
  
 

    public int delete(String sql) throws SQLException,Exception{
    	sentencia = miConexionBD.createStatement();
        return sentencia.executeUpdate(sql);
   /* 
            Statement sentencia=mBD.createStatement();
            sentencia.executeQuery(SQL);
    */
    }   

    public int update(String sql) throws SQLException,Exception{  
    	sentencia = miConexionBD.createStatement();
        return sentencia.executeUpdate(sql);

    } 
    public ResultSet read(String sql) throws SQLException,Exception{
        sentencia = miConexionBD.createStatement();
        return sentencia.executeQuery(sql);  //devuelve el resultado de la consulta
       
    } 
    public int create(String sql) throws SQLException,Exception{
    	 sentencia = miConexionBD.createStatement();
         return sentencia.executeUpdate(sql);

} 
    

}

