package org.ModulePacientes;


public class Paciente {
	private int id_paciente;
	private String nombre;
	private String apellido;
	private String fecha_nacimiento;
	private String dni;
	
	
	public Paciente(int id_paciente,String nombre, String apellido, String fecha_nacimiento,
			String dni) {
		super();
		this.setId_paciente(id_paciente);
		this.setNombre(nombre);
		this.setApellido(apellido);
		this.setfecha_nacimiento(fecha_nacimiento);
		this.setDni(dni);

	}
	
	public void setNombre(String nombre){
		this.nombre = nombre;
	}
	public void setApellido(String apellido){
		this.apellido = apellido;
	}
	public void setfecha_nacimiento(String fecha){
		this.fecha_nacimiento = fecha;
	}
	public void setDni(String dni){
		this.dni=dni;
	}
	

	public void modificar_paciente(String nombre, String apellido, String fecha_nacimiento,
			String dni){
		this.nombre = nombre;
		this.apellido = apellido;
		this.fecha_nacimiento = fecha_nacimiento;
		this.dni = dni;
		
		
	}
	public int getIdPaciente(){
		return this.id_paciente;
	}
	public String getNombre() {
		return nombre;
	}


	public String getApellido() {
		return apellido;
	}



	public String getFecha_nacimiento() {
		return fecha_nacimiento;
	}



	public int getId_paciente() {
		return id_paciente;
	}

	public void setId_paciente(int id_paciente) {
		this.id_paciente = id_paciente;
	}

	public String getDni() {
		return dni;
	}

	public String getIdNombreApellido(){
		return Integer.toString(this.getId_paciente()) +" "+ this.getNombre()+" "+this.getApellido();
	}

	

	
	
	
	
	
	
	
	
	

}